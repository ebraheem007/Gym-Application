package com.myfirstappp.ii

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class CheckExercises : AppCompatActivity() {
    private val exerciseList = listOf(
        "Squats",
        "Push-ups",
        "Lunges",
        "Bench Press",
        "Dead-lifts",
        "Shoulder Press",
        "Bicep curls",
        "Tricep dips",
        "Plank",
        "Leg Press"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_check_exercises)

        val listView: ListView = findViewById(R.id.exerciseListView)
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, exerciseList)
        listView.adapter = adapter
    }
}
