package com.myfirstappp.ii

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var editTextEmail: EditText
    private lateinit var editTextPassword: EditText
    private lateinit var buttonLogin: Button

    private val PASSWORD_LENGTH = 6

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextEmail = findViewById(R.id.editTextEmail)
        editTextPassword = findViewById(R.id.editTextPassword)
        buttonLogin = findViewById(R.id.buttonLogin)

        buttonLogin.setOnClickListener {
            val email = editTextEmail.text.toString()
            val password = editTextPassword.text.toString()

            if (email.isNotEmpty() && password.length == PASSWORD_LENGTH) {
                if (email == "ucp@gmail.com" && password == "123456") {

                    val intent = Intent(this@MainActivity, HomeActivity::class.java)
                    startActivity(intent)
                } else {

                    Toast.makeText(this@MainActivity, "Invalid email or password.", Toast.LENGTH_SHORT).show()
                }
            } else {
                if (password.length < PASSWORD_LENGTH) {
                    Toast.makeText(this@MainActivity, "Password should be $PASSWORD_LENGTH characters long.", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@MainActivity, "Please enter email and password.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
