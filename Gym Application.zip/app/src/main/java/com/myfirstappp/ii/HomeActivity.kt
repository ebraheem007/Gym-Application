package com.myfirstappp.ii


import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class HomeActivity : AppCompatActivity() {

    private lateinit var buttonCheckBMI: Button
    private lateinit var buttonCheckExercise: Button

    private val exerciseList = listOf(
        "Exercise 1",
        "Exercise 2",
        "Exercise 3",
        "Exercise 4",
        "Exercise 5"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        buttonCheckBMI = findViewById(R.id.CheckBMI)
        buttonCheckExercise = findViewById(R.id.CheckExercise)

        buttonCheckBMI.setOnClickListener {
            // Handle button click for checking BMI
            val intent= Intent(this@HomeActivity, BMIActivity::class.java)
            startActivity(intent)
        }

        buttonCheckExercise.setOnClickListener {
            // Handle button click for checking exercise
            val intent=Intent(this@HomeActivity, CheckExercises::class.java)
            startActivity(intent)
        }
    }
}
