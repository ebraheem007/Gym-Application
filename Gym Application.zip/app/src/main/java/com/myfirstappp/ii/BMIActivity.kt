package com.myfirstappp.ii

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class BMIActivity : AppCompatActivity() {

    private lateinit var editTextWeight: EditText
    private lateinit var editTextHeight: EditText
    private lateinit var buttonCalculate: Button
    private lateinit var textViewResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.bmi_layout)

        editTextWeight = findViewById(R.id.editTextWeight)
        editTextHeight = findViewById(R.id.editTextHeight)
        buttonCalculate = findViewById(R.id.buttonCalculate)
        textViewResult = findViewById(R.id.textViewResult)

        buttonCalculate.setOnClickListener {
            calculateBMI()
        }
    }

    @SuppressLint("SetTextI18n")
    private fun calculateBMI() {
        val weight = editTextWeight.text.toString().toDoubleOrNull()
        val heightInCm = editTextHeight.text.toString().toDoubleOrNull()

        if (weight != null && heightInCm != null) {
            val heightInM = heightInCm / 100.0
            val bmi = weight / (heightInM * heightInM)
            val result = String.format("Your BMI: %.2f", bmi)
            textViewResult.text = result
        } else {
            textViewResult.text = "Invalid input"
        }
    }

}
